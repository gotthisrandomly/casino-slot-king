# Slot King Casino - Static Demo

A static demonstration of the Slot King Casino application.

## About

This is a simplified, static version of the Slot King Casino application, designed for preview purposes.

